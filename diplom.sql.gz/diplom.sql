-- phpMyAdmin SQL Dump
-- version 4.7.3
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1:3306
-- Время создания: Дек 01 2017 г., 17:33
-- Версия сервера: 5.6.37
-- Версия PHP: 5.5.38

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `diplom`
--

-- --------------------------------------------------------

--
-- Структура таблицы `File`
--

CREATE TABLE `File` (
  `link` text NOT NULL,
  `id_st` int(11) NOT NULL,
  `id_ls` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `File`
--

INSERT INTO `File` (`link`, `id_st`, `id_ls`) VALUES
('https://www.google.ru/', 2, 1),
('https://www.google.ru/', 5, 3),
('https://www.google.ru/', 4, 1),
('https://www.google.ru/', 6, 3),
('https://www.google.ru/', 7, 3),
('https://www.google.ru/', 3, 4);

-- --------------------------------------------------------

--
-- Структура таблицы `Groupe`
--

CREATE TABLE `Groupe` (
  `id_gr` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `Groupe`
--

INSERT INTO `Groupe` (`id_gr`) VALUES
(3301),
(3302);

-- --------------------------------------------------------

--
-- Структура таблицы `lesson`
--

CREATE TABLE `lesson` (
  `id_ls` int(11) NOT NULL,
  `name` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `lesson`
--

INSERT INTO `lesson` (`id_ls`, `name`) VALUES
(1, 'Вычислительные системы'),
(2, 'Информационные технологии в проектировании'),
(3, 'Сетевое web-программирования'),
(4, 'Математические основы информатики');

-- --------------------------------------------------------

--
-- Структура таблицы `les_to_gr`
--

CREATE TABLE `les_to_gr` (
  `id_ls` int(11) NOT NULL,
  `id_gr` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `les_to_gr`
--

INSERT INTO `les_to_gr` (`id_ls`, `id_gr`) VALUES
(4, 3301),
(4, 3301),
(1, 3301),
(1, 3301),
(2, 3301),
(2, 3301),
(3, 3302),
(3, 3301);

-- --------------------------------------------------------

--
-- Структура таблицы `student`
--

CREATE TABLE `student` (
  `id_st` int(11) NOT NULL,
  `FIO` text NOT NULL,
  `birthday` date NOT NULL,
  `status` tinyint(1) NOT NULL,
  `gr_numb` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `student`
--

INSERT INTO `student` (`id_st`, `FIO`, `birthday`, `status`, `gr_numb`) VALUES
(2, 'Миннагалиев Альберт Юрьевич', '1995-11-16', 1, 3302),
(3, 'Пушкин Александр Сергеевич', '2017-12-13', 1, 3302),
(4, 'Бондарчук Сергей Иванович', '2017-12-15', 1, 3302),
(5, 'Барышев Сергей Владимирович', '2017-12-14', 1, 3301),
(6, 'Джеймс Гослинг', '2017-12-14', 0, 3301),
(7, 'Серге́й Миха́йлович Брин', '2017-12-13', 1, 3301);

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `File`
--
ALTER TABLE `File`
  ADD KEY `id_st` (`id_st`),
  ADD KEY `id_ls` (`id_ls`);

--
-- Индексы таблицы `Groupe`
--
ALTER TABLE `Groupe`
  ADD PRIMARY KEY (`id_gr`);

--
-- Индексы таблицы `lesson`
--
ALTER TABLE `lesson`
  ADD PRIMARY KEY (`id_ls`);

--
-- Индексы таблицы `les_to_gr`
--
ALTER TABLE `les_to_gr`
  ADD KEY `id_ls` (`id_ls`),
  ADD KEY `id_gr` (`id_gr`);

--
-- Индексы таблицы `student`
--
ALTER TABLE `student`
  ADD PRIMARY KEY (`id_st`),
  ADD KEY `gr_numb` (`gr_numb`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `lesson`
--
ALTER TABLE `lesson`
  MODIFY `id_ls` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT для таблицы `student`
--
ALTER TABLE `student`
  MODIFY `id_st` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- Ограничения внешнего ключа сохраненных таблиц
--

--
-- Ограничения внешнего ключа таблицы `File`
--
ALTER TABLE `File`
  ADD CONSTRAINT `file_ibfk_1` FOREIGN KEY (`id_st`) REFERENCES `student` (`id_st`),
  ADD CONSTRAINT `file_ibfk_2` FOREIGN KEY (`id_ls`) REFERENCES `lesson` (`id_ls`);

--
-- Ограничения внешнего ключа таблицы `les_to_gr`
--
ALTER TABLE `les_to_gr`
  ADD CONSTRAINT `les_to_gr_ibfk_1` FOREIGN KEY (`id_gr`) REFERENCES `Groupe` (`id_gr`),
  ADD CONSTRAINT `les_to_gr_ibfk_2` FOREIGN KEY (`id_ls`) REFERENCES `lesson` (`id_ls`);

--
-- Ограничения внешнего ключа таблицы `student`
--
ALTER TABLE `student`
  ADD CONSTRAINT `student_ibfk_1` FOREIGN KEY (`gr_numb`) REFERENCES `Groupe` (`id_gr`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
